
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import util.HibernateUtil;


public class TestaConexão {
    public static void main(String[] args) {
        // captura a fabrica de sessões
        
     SessionFactory fabrica = HibernateUtil.getSessionFactory();
        
        
        // capturar uma sessão aberta
        Session sessao = fabrica.openSession();
        
        // troca de informações entre a aplicação e o banco de dados
        
        // fecha a sessão aberta
        sessao.close();
        
        
        // fecha a fabrica de sessões
        fabrica.close();
    }
    
}
