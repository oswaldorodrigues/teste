/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bean;

import DAO.ClienteDAO;
import Entidades.Cliente;

import java.io.Serializable;

import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

/**
 * Classe para.....
 *
 * @author Guilherme Montanher.
 * @since Classe criada em 27/08/2016
 */
@ManagedBean
@SessionScoped
public class ClienteBean implements Serializable {

    private Cliente cliente;
    private List<Cliente> clientes;
    
       public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public List<Cliente> getClientes() {
        return clientes;
    }

    public void setClientes(List<Cliente> clientes) {
        this.clientes = clientes;
    }
    @PostConstruct
    public void listar() {
        try {
            clientes = new ClienteDAO().listar();
        } catch (RuntimeException erro) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Ocorreu um erro ao tentar listar as clientes."));
            erro.printStackTrace();
        }
    }

    public void novo() {
        try {
            cliente = new Cliente();
           clientes = new ClienteDAO().listar();
          
            
        } catch (RuntimeException erro) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Ocorreu um erro ao tentar listar os clienteS."));
            erro.printStackTrace();
        }
    }

    public void salvar() {
        try {
            ClienteDAO clienteDAO = new ClienteDAO();

            clienteDAO.merge(cliente);

            novo();
            clientes = clienteDAO.listar();
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("cliente salva com sucesso!"));

        } catch (RuntimeException erro) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Ocorreu um erro ao tentar salvar a cliente."+erro.getMessage()));
            erro.printStackTrace();
        }
    }

    public void excluir(ActionEvent evento) {
        try {
            cliente = (Cliente) evento.getComponent().getAttributes().get("clienteSelecionada");
           ClienteDAO clienteDAO = new ClienteDAO();
            clienteDAO.excluir(cliente);
           clientes = clienteDAO.listar();

            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("cliente excluído com sucesso!"));
        } catch (RuntimeException erro) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Ocorreu um erro ao remover"));
            erro.printStackTrace();
        }

    }

    public void editar(ActionEvent evento) {
        try {
            cliente = (Cliente) evento.getComponent().getAttributes().get("clienteSelecionado");

            clientes = new ClienteDAO().listar();
        } catch (RuntimeException erro) {

        }
    }

    public void visualizar(ActionEvent evento) {
        try {
            cliente = (Cliente) evento.getComponent().getAttributes().get("clienteSelecionada");
            clientes = new ClienteDAO().listar();
            
        } catch (RuntimeException erro) {

        }
    }


   

}//fim da classe.
