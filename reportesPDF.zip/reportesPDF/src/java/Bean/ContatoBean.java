
package Bean;

import DAO.ContatoDAO;
import Entidades.Contato;
import java.io.Serializable;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

/**
 *
 * @author oswaldo
 */
@ManagedBean
@SessionScoped
public class ContatoBean implements Serializable {

    private Contato contato;
    private List<Contato> contatos;
  
    public Contato getContato() {
        return contato;
    }

    public void setContato(Contato contato) {
        this.contato = contato;
    }

    public List<Contato> getContatos() {
        return contatos;
    }

    public void setContatos(List<Contato> contatos) {
        this.contatos = contatos;
    }

 
 
    @PostConstruct
    public void listar() {
        try {
            contatos = new ContatoDAO().listar();
        } catch (RuntimeException erro) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Ocorreu um erro ao tentar listar as contato."));
            erro.printStackTrace();
        }
    }

    public void novo() {
        try {
            contato = new Contato();

        } catch (RuntimeException erro) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Ocorreu um erro ao tentar listar as contato."));
            erro.printStackTrace();
        }
    }

    public void salvar() {
        try {
            ContatoDAO contatoDAO = new ContatoDAO();
            contatoDAO.merge(contato);

            novo();
            contatos = contatoDAO.listar();
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("contato salvo com sucesso!"));
        } catch (RuntimeException erro) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Ocorreu um erro ao tentar salvar o contato."));
            erro.printStackTrace();
        }
    }

    public void excluir(ActionEvent evento) {
        try {
            contato = (Contato) evento.getComponent().getAttributes().get("contatoSelecionado");
            ContatoDAO contatoDAO = new ContatoDAO();
            contatoDAO.excluir(contato);
            contatos = contatoDAO.listar();

            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("contato excluído com sucesso!"));
        } catch (RuntimeException erro) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Ocorreu um erro ao remover"));
            erro.printStackTrace();
        }

    }

    public void editar(ActionEvent evento) {

        try {
            contato = (Contato) evento.getComponent().getAttributes().get("contatoSelecionado");

           
        } catch (RuntimeException erro) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Ocorreu um erro ao tentar listar as contato."));
            erro.printStackTrace();
        }
    }
public void visualizar(ActionEvent evento) {
        try {
            contato = (Contato) evento.getComponent().getAttributes().get("contatoSelecionada");
            contatos = new ContatoDAO().listar();
        } catch (RuntimeException erro) {

        }
    }

    
    
   
}//fim da classe.
