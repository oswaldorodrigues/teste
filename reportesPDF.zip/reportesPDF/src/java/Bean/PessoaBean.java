/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bean;

import DAO.ContatoDAO;
import DAO.EnderecoDAO;

import DAO.PessoaDAO;
import Entidades.Contato;
import Entidades.Endereco;

import Entidades.Pessoa;
import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

/**
 * Classe para.....
 *
 * @author Guilherme Montanher.
 * @since Classe criada em 27/08/2016
 */
@ManagedBean
@SessionScoped
public class PessoaBean implements Serializable {

    private Pessoa pessoa;
    private List<Pessoa> pessoas;
   
    
    

    public Pessoa getPessoa() {
        return pessoa;
    }

    public void setPessoa(Pessoa pessoa) {
        this.pessoa = pessoa;
    }

    public List<Pessoa> getPessoas() {
        return pessoas;
    }

    public void setPessoas(List<Pessoa> pessoas) {
        this.pessoas = pessoas;
    }

   

    @PostConstruct
    public void listar() {
        try {
            pessoas = new PessoaDAO().listar();
        } catch (RuntimeException erro) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Ocorreu um erro ao tentar listar as pessoas."));
            erro.printStackTrace();
        }
    }

    public void novo() {
        try {
            pessoa = new Pessoa();
            pessoas = new PessoaDAO().listar();
          
            
        } catch (RuntimeException erro) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Ocorreu um erro ao tentar listar os pessoas."));
            erro.printStackTrace();
        }
    }

    public void salvar() {
        try {
            PessoaDAO pessoaDAO = new PessoaDAO();
            
            if(pessoa.getDtCadastro() == null){
                pessoa.setDtCadastro(new Date());
            }
            pessoaDAO.merge(pessoa);

            novo();
            pessoas = pessoaDAO.listar();
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Pessoa salva com sucesso!"));

        } catch (RuntimeException erro) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Ocorreu um erro ao tentar salvar a pessoa."+erro.getMessage()));
            erro.printStackTrace();
        }
    }

    public void excluir(ActionEvent evento) {
        try {
            pessoa = (Pessoa) evento.getComponent().getAttributes().get("pessoaSelecionada");
            PessoaDAO pessoaDAO = new PessoaDAO();
            pessoaDAO.excluir(pessoa);
            pessoas = pessoaDAO.listar();

            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Estado excluído com sucesso!"));
        } catch (RuntimeException erro) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Ocorreu um erro ao remover"));
            erro.printStackTrace();
        }

    }

    public void editar(ActionEvent evento) {
        try {
            pessoa = (Pessoa) evento.getComponent().getAttributes().get("pessoaSelecionada");

            pessoas = new PessoaDAO().listar();
        } catch (RuntimeException erro) {

        }
    }

    public void visualizar(ActionEvent evento) {
        try {
            pessoa = (Pessoa) evento.getComponent().getAttributes().get("pessoaSelecionada");
            pessoas = new PessoaDAO().listar();
            
        } catch (RuntimeException erro) {

        }
    }

   

}//fim da classe.
