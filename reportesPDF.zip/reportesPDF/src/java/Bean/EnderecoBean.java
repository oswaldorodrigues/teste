/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bean;


import DAO.EnderecoDAO;
import Entidades.Endereco;

import java.io.Serializable;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

/**
 * Classe para.....
 *
 * @author Guilherme Montanher.
 * @since Classe criada em 13/09/2016
 */
@ManagedBean
@SessionScoped
public class EnderecoBean implements Serializable {

    private Endereco endereco;
    private List<Endereco> enderecos;
 

    public Endereco getEndereco() {
        return endereco;
    }

    public void setEndereco(Endereco endereco) {
        this.endereco = endereco;
    }

    public List<Endereco> getEnderecos() {
        return enderecos;
    }

    public void setEnderecos(List<Endereco> enderecos) {
        this.enderecos = enderecos;
    }

   

    @PostConstruct
    public void listar() {
        try {
            enderecos = new EnderecoDAO().listar();
        } catch (RuntimeException erro) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Ocorreu um erro ao tentar listar as endereços."));
            erro.printStackTrace();
        }
    }

    public void novo() {
        try {
            endereco = new Endereco();

        } catch (RuntimeException erro) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Ocorreu um erro ao tentar listar as cidades."));
            erro.printStackTrace();
        }
    }

    public void salvar() {
        try {
            EnderecoDAO enderecoDAO = new EnderecoDAO();
            enderecoDAO.merge(endereco);

            novo();
            enderecos = enderecoDAO.listar();
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Endereço salvo com sucesso!"));
        } catch (RuntimeException erro) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Ocorreu um erro ao tentar salvar o endereço."));
            erro.printStackTrace();
        }
    }

    public void excluir(ActionEvent evento) {
        try {
            endereco = (Endereco) evento.getComponent().getAttributes().get("enderecoSelecionado");
            EnderecoDAO enderecoDAO = new EnderecoDAO();
            enderecoDAO.excluir(endereco);
            enderecos = enderecoDAO.listar();

            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Endereço excluído com sucesso!"));
        } catch (RuntimeException erro) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Ocorreu um erro ao remover"));
            erro.printStackTrace();
        }

    }

    public void editar(ActionEvent evento) {

        try {
            endereco = (Endereco) evento.getComponent().getAttributes().get("enderecoSelecionado");

           
        } catch (RuntimeException erro) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Ocorreu um erro ao tentar listar as cidades."));
            erro.printStackTrace();
        }
    }
}//fim da classe.
