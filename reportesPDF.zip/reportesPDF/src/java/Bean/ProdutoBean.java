/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bean;


import DAO.CategoriaDAO;
import DAO.ProdutoDAO;
import Entidades.Categoria;
import Entidades.Produto;

import java.io.Serializable;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

/**
 * Classe para.....
 *
 * @author Guilherme Montanher.
 * @since Classe criada em 13/09/2016
 */
@ManagedBean
@SessionScoped
public class ProdutoBean implements Serializable {

    private Produto produto;
    private List<Produto> produtos;
    private List<Categoria> categorias;
    
 
 public Produto getProduto() {
        return produto;
    }

    public void setProduto(Produto produto) {
        this.produto = produto;
    }

    public List<Produto> getProdutos() {
        return produtos;
    }

    public void setProdutos(List<Produto> produtos) {
        this.produtos = produtos;
    }
     public List<Categoria> getCategorias() {
        return categorias;
    }

    public void setCategorias(List<Categoria> categorias) {
        this.categorias = categorias;
    }
   

    @PostConstruct
    public void listar() {
        try {
            produtos = new ProdutoDAO().listar();
        } catch (RuntimeException erro) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Ocorreu um erro ao tentar listar as produto."));
            erro.printStackTrace();
        }
    }

    public void novo() {
        try {
            produto = new Produto();
categorias = new CategoriaDAO().listar();
        } catch (RuntimeException erro) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Ocorreu um erro ao tentar listar as produto."));
            erro.printStackTrace();
        }
    }

    public void salvar() {
        try {
            ProdutoDAO produtoDAO = new ProdutoDAO();
            produtoDAO.merge(produto);

            novo();
            produtos = produtoDAO.listar();
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("produto salvo com sucesso!"));
        } catch (RuntimeException erro) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Ocorreu um erro ao tentar salvar o produto."));
            erro.printStackTrace();
        }
    }

    public void excluir(ActionEvent evento) {
        try {
            produto = (Produto) evento.getComponent().getAttributes().get("produtoSelecionado");
            ProdutoDAO produtoDAO = new ProdutoDAO();
            produtoDAO.excluir(produto);
            produtos = produtoDAO.listar();

            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("produto excluído com sucesso!"));
        } catch (RuntimeException erro) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Ocorreu um erro ao remover"));
            erro.printStackTrace();
        }

    }

    public void editar(ActionEvent evento) {

        try {
            produto = (Produto) evento.getComponent().getAttributes().get("produtoSelecionado");

           categorias = new CategoriaDAO().listar();
        } catch (RuntimeException erro) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Ocorreu um erro ao tentar listar as produto."));
            erro.printStackTrace();
        }
    }

  

   
}//fim da classe.
