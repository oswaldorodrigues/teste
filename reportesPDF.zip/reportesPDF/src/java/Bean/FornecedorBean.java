/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bean;


import DAO.ContatoDAO;
import DAO.EnderecoDAO;
import DAO.FornecedorDAO;
import Entidades.Contato;
import Entidades.Endereco;

import Entidades.Fornecedor;
import java.io.Serializable;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

/**
 * Classe para.....
 *
 * @author Guilherme Montanher.
 * @since Classe criada em 27/08/2016
 */
@ManagedBean
@SessionScoped
public class FornecedorBean implements Serializable {

    private Fornecedor fornecedor;
    private List<Fornecedor> fornecedores;
    private List<Endereco> enderecos;
    
    private List<Contato> contatos;
    
     public List<Contato> getContatos() {
        return contatos;
    }

    public void setContatos(List<Contato> contatos) {
        this.contatos = contatos;
    }
    
    
    

    public Fornecedor getFornecedor() {
        return fornecedor;
    }

    public void setFornecedor(Fornecedor fornecedor) {
        this.fornecedor = fornecedor;
    }

    public List<Fornecedor> getFornecedores() {
        return fornecedores;
    }

    public void setFornecedores(List<Fornecedor> fornecedores) {
        this.fornecedores = fornecedores;
    }
    
     public List<Endereco> getEnderecos() {
        return enderecos;
    }

    public void setEnderecos(List<Endereco> enderecos) {
        this.enderecos = enderecos;
    }

    @PostConstruct
    public void listar() {
        try {
            fornecedores = new FornecedorDAO().listar();
        } catch (RuntimeException erro) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Ocorreu um erro ao tentar listar os fornecedores."));
            erro.printStackTrace();
        }
    }

    public void novo() {
        fornecedor = new Fornecedor();
        enderecos = new EnderecoDAO().listar();
        contatos = new ContatoDAO().listar();
    }

    public void salvar() {
        FornecedorDAO fornecedorDAO = new FornecedorDAO();
        fornecedorDAO.merge(fornecedor);

        novo();
        fornecedores = fornecedorDAO.listar();
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Fornecedor salvo com sucesso!"));
    }

    public void excluir(ActionEvent evento) {
        try {
            fornecedor = (Fornecedor) evento.getComponent().getAttributes().get("fornecedorSelecionado");
            FornecedorDAO fornecedorDAO = new FornecedorDAO();
            fornecedorDAO.excluir(fornecedor);
            fornecedores = fornecedorDAO.listar();

            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Fornecedor excluído com sucesso!"));
        } catch (RuntimeException erro) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Ocorreu um erro ao remover"));
            erro.printStackTrace();
        }

    }
    
    public void editar(ActionEvent evento) {
        try {
            fornecedor = (Fornecedor) evento.getComponent().getAttributes().get("fornecedorSelecionado");
            enderecos = new EnderecoDAO().listar();
            
        }catch (RuntimeException erro){
            
        }
    }
public void visualizar(ActionEvent evento) {
        try {
            fornecedor = (Fornecedor) evento.getComponent().getAttributes().get("fornecedorSelecionada");
             enderecos = new EnderecoDAO().listar();
            contatos = new ContatoDAO().listar();
            
        } catch (RuntimeException erro) {

        }
    }
   

}//fim da classe.
