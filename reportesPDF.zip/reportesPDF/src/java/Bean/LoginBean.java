/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bean;

import DAO.UsuarioDAO;
import Entidades.Pessoa;
import Entidades.Usuario;
import java.io.IOException;
import util.HibernateUtil;
import java.io.Serializable;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.omnifaces.util.Faces;
import org.omnifaces.util.Messages;

/**
 * Classe para.....
 *
 * @author Guilherme Montanher.
 * @since Classe criada em 19/09/2016
 */
@ManagedBean
@SessionScoped
public class LoginBean implements Serializable {

    private Usuario usuario;
    
    

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }
    
    
   @PostConstruct
   public void iniciar(){
       usuario = new Usuario();
       
       usuario.setPessoa(new Pessoa());
   }
   
   public void autenticar(){
       
       try{
          UsuarioDAO usuarioDAO= new UsuarioDAO();
         Usuario usuarioLogado = usuarioDAO.altenticar(usuario.getPessoa().getCpf(), usuario.getSenha());
           
           if (usuarioLogado == null){
              Messages.addGlobalError("CPF e/ ou senha incorretos");
             return;
           }
             
          
         Faces.redirect("./faces/Menu.xhtml");
           
       }catch(IOException erro){
           erro.printStackTrace();
           Messages.addGlobalError(erro.getMessage());
       }
   }

   

}//fim da classe.
