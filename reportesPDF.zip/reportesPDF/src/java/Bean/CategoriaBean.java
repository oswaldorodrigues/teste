
package Bean;

import DAO.CategoriaDAO;
import DAO.ProdutoDAO;
import Entidades.Categoria;
import Entidades.Produto;
import java.io.Serializable;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

/**
 * Classe para.....
 *
 * @author Guilherme Montanher.
 * @since Classe criada em 13/09/2016
 */
@ManagedBean
@SessionScoped
public class CategoriaBean implements Serializable {

    private Categoria categoria;
    private List<Categoria> categorias;
    private List<Produto> produtos;
    
 
 public Categoria getCategoria() {
        return categoria;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }

    public List<Categoria> getCategorias() {
        return categorias;
    }

    public void setCategorias(List<Categoria> categorias) {
        this.categorias = categorias;
    }
    public List<Produto> getProdutos() {
        return produtos;
    }

    public void setProdutos(List<Produto> produtos) {
        this.produtos = produtos;
    }
    
    
    @PostConstruct
    public void listar() {
        try {
            categorias = new CategoriaDAO().listar();
        } catch (RuntimeException erro) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Ocorreu um erro ao tentar listar as categoria."));
            erro.printStackTrace();
        }
    }

    public void novo() {
        try {
            categoria = new Categoria();

        } catch (RuntimeException erro) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Ocorreu um erro ao tentar listar as categoria."));
            erro.printStackTrace();
        }
    }

    public void salvar() {
        try {
            CategoriaDAO categoriaDAO = new CategoriaDAO();
            categoriaDAO.merge(categoria);

            novo();
            categorias = categoriaDAO.listar();
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("categoria salvo com sucesso!"));
        } catch (RuntimeException erro) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Ocorreu um erro ao tentar salvar o categoria."));
            erro.printStackTrace();
        }
    }

    public void excluir(ActionEvent evento) {
        try {
            categoria = (Categoria) evento.getComponent().getAttributes().get("categoriaSelecionado");
            CategoriaDAO categoriaDAO = new CategoriaDAO();
            categoriaDAO.excluir(categoria);
            categorias = categoriaDAO.listar();

            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("categoria excluído com sucesso!"));
        } catch (RuntimeException erro) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Ocorreu um erro ao remover"));
            erro.printStackTrace();
        }

    }

    public void editar(ActionEvent evento) {

        try {
            categoria = (Categoria) evento.getComponent().getAttributes().get("categoriaSelecionado");

           
        } catch (RuntimeException erro) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Ocorreu um erro ao tentar listar as categoria."));
            erro.printStackTrace();
        }
    }
public void visualizar(ActionEvent evento) {
        try {
            categoria = (Categoria) evento.getComponent().getAttributes().get("categoriaSelecionada");
            produtos = new ProdutoDAO().listar();
        } catch (RuntimeException erro) {

        }
    }

    
   
}//fim da classe.
