/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bean;



import DAO.ContatoDAO;
import DAO.EnderecoDAO;
import DAO.FuncionarioDAO;
import DAO.PessoaDAO;
import Entidades.Contato;
import Entidades.Endereco;

import Entidades.Funcionario;
import Entidades.Pessoa;



import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

/**
 * Classe para.....
 *
 * @author oswaldo rodrigues.
 * @since Classe criada em 27/08/2016
 */
@ManagedBean
@SessionScoped
public class FuncionarioBean implements Serializable {

     private Funcionario funcionario;
    private List<Funcionario> funcionarios;
      private List<Pessoa> pessoas;
      private List<Endereco> enderecos;
      private List<Contato> contatos;
    
     public List<Contato> getContatos() {
        return contatos;
    }

    public void setContatos(List<Contato> contatos) {
        this.contatos = contatos;
    }
      
      
   
   
public List<Funcionario> getFuncionarios() {
        return funcionarios;
    }

    public void setFuncionarios(List<Funcionario> funcionarios) {
        this.funcionarios = funcionarios;
    }

    public Funcionario getFuncionario() {
        return funcionario;
    }

    public void setFuncionario(Funcionario funcionario) {
        this.funcionario = funcionario;
    }
    
     public List<Pessoa> getPessoas() {
        return pessoas;
    }

    public void setPessoas(List<Pessoa> pessoas) {
        this.pessoas = pessoas;
    }
    
     public List<Endereco> getEnderecos() {
        return enderecos;
    }

    public void setEnderecos(List<Endereco> enderecos) {
        this.enderecos = enderecos;
    }
    
//getter and setter
  
    @PostConstruct
    public void listar() {
        try {
            funcionarios = new FuncionarioDAO().listar();
        } catch (RuntimeException erro) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Ocorreu um erro ao tentar listar as funcionarios."));
            erro.printStackTrace();
        }
    }

    public void novo() {
        try {
            funcionario = new Funcionario();
pessoas = new PessoaDAO().listar();
enderecos = new EnderecoDAO().listar();
  contatos = new ContatoDAO().listar();
        } catch (RuntimeException erro) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Ocorreu um erro ao tentar listar as funcionario."));
            erro.printStackTrace();
        }
    }

    public void salvar() {
        try {
            FuncionarioDAO funcionarioDAO = new FuncionarioDAO();
            funcionarioDAO.merge(funcionario);

            novo();
            funcionarios = funcionarioDAO.listar();
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("funcionario salvo com sucesso!"));
        } catch (RuntimeException erro) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Ocorreu um erro ao tentar salvar o funcionario."));
            erro.printStackTrace();
        }
    }

    public void excluir(ActionEvent evento) {
        try {
            funcionario = (Funcionario) evento.getComponent().getAttributes().get("funcionarioSelecionado");
            FuncionarioDAO funcionarioDAO = new FuncionarioDAO();
            funcionarioDAO.excluir(funcionario);
            funcionarios = funcionarioDAO.listar();

            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("funcionario excluído com sucesso!"));
        } catch (RuntimeException erro) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Ocorreu um erro ao remover"));
            erro.printStackTrace();
        }

    }

    public void editar(ActionEvent evento) {

        try {
            funcionario = (Funcionario) evento.getComponent().getAttributes().get("funcionarioSelecionado");
pessoas = new PessoaDAO().listar();
enderecos = new EnderecoDAO().listar();
           
        } catch (RuntimeException erro) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Ocorreu um erro ao tentar listar as funcionario."));
            erro.printStackTrace();
        }
    }

   

   

}//fim da classe.
