
package DAO;

import Entidades.ModeloProduto;

public class ModeloProdutoDAO extends GenericDAO<ModeloProduto> {

}//fim da classe.
