package DAO;

import Entidades.Pessoa;

public class PessoaDAO extends GenericDAO<Pessoa> {

}
