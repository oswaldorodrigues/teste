package DAO;

import Entidades.Funcionario;

public class FuncionarioDAO extends GenericDAO<Funcionario> {


}
