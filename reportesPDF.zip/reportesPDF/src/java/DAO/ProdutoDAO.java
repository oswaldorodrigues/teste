
package DAO;

import Entidades.Produto;


public class ProdutoDAO extends GenericDAO<Produto> {

}//fim da classe.
