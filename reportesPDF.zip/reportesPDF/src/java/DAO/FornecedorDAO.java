package DAO;

import Entidades.Fornecedor;

public class FornecedorDAO extends GenericDAO<Fornecedor> {

} 
