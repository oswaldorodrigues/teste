
package DAO;

import Entidades.Contato;

/**
 *
 * @author oswaldo
 */
public class ContatoDAO extends GenericDAO<Contato>{
    
}
