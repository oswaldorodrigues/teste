

package DAO;

import Entidades.Usuario;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import util.HibernateUtil;


public class UsuarioDAO extends GenericDAO<Usuario> {
    
     public Usuario altenticar(String cpf, String Senha) {
        Session sessao = HibernateUtil.getSessionFactory().openSession();
        try {
            Criteria consulta = sessao.createCriteria(Usuario.class);
            consulta.createAlias("pessoa","p");
            consulta.add(Restrictions.eq("p.cpf",cpf));
            //SimpleHash hash = new SimpleHash("md5",senha);
            Usuario resultado = (Usuario) consulta.uniqueResult();
            return resultado;
            
        } catch (RuntimeException erro) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Falha ao logar."));
            throw erro;
        } finally {
            sessao.close();
        }
    }
    
    

}//fim da classe.
