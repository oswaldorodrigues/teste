package DAO;

import Entidades.Cliente;

public class ClienteDAO extends GenericDAO<Cliente> {

} 
