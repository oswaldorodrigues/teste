
package DAO;

import Entidades.Categoria;

public class CategoriaDAO extends GenericDAO<Categoria>{

}//fim da classe.
