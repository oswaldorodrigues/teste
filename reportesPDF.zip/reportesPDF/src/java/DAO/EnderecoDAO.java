package DAO;

import Entidades.Endereco;

public class EnderecoDAO extends GenericDAO<Endereco> {

} 
