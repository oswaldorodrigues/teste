package Entidades;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import java.util.Date;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@SuppressWarnings("serial")
@Entity
public class Pessoa extends GenericDomain {
    

    @Column(length = 150, nullable = false)
    private String nome;

    @Column(length = 40, nullable = false)
    private String cpf;

    @Column(length = 40, nullable = false)
    private String rg;

   

    @Column(nullable = false)
    @Temporal(TemporalType.DATE)
    private Date dtNascimento;
    
  
    
    @Column(length = 15, nullable = false)
    private String sexo;

   

    @Column(nullable = false)
    @Temporal(TemporalType.DATE)
    private Date dtCadastro;
    
    
    // getter and setter
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getRg() {
        return rg;
    }

    public void setRg(String rg) {
        this.rg = rg;
    }

    public Date getDtNascimento() {
        return dtNascimento;
    }

    public void setDtNascimento(Date dtNascimento) {
        this.dtNascimento = dtNascimento;
    }

   

  

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

   

    public Date getDtCadastro() {
        return dtCadastro;
    }

    public void setDtCadastro(Date dtCadastro) {
        this.dtCadastro = dtCadastro;
    }

   

}
