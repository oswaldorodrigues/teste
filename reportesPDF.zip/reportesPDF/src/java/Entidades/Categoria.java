package Entidades;

/**
 * Classe para.....
 *
 * @author oswaldo rodrigues
 * @since Classe criada em 22/08/2016
 */
import javax.persistence.Column;
import javax.persistence.Entity;

@SuppressWarnings("serial")
@Entity
public class Categoria extends GenericDomain {

    @Column(length = 50, nullable = false)
    private String descricao;

    @Column(length = 20, nullable = false)
    private String status;
    
    //gettt and setter

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

 
    
    
}//fim da classe.
