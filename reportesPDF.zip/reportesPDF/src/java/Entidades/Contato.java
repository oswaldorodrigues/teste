
package Entidades;

import javax.persistence.Column;
import javax.persistence.Entity;

/**
 *
 * @author oswaldo
 */
@SuppressWarnings("serial")
@Entity
public class Contato extends GenericDomain{
    
     @Column(length = 50, nullable = false)
    private String telefone;
    
    @Column(length = 50, nullable = true)
    private String celular;

    @Column(length = 120, nullable = true)
    private String email;

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getCelular() {
        return celular;
    }

    public void setCelular(String celular) {
        this.celular = celular;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    
    
}
