
package Entidades;

/**
 * Classe para.....
 *
 * @author OSWALDO.
 * @since Classe criada em 15/08/2016
 */
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@SuppressWarnings("serial")
@Entity
public class Cliente extends GenericDomain {

 @Column(length = 150, nullable = true)
    private String nome;

    @Column(length = 40, nullable = true)
    private String cpf;

    //@Column(nullable = true)
    //@Temporal(TemporalType.DATE)
   // private Date dtNascimento;

    @Column(length = 15, nullable = true)
    private String sexo;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }
    
    
}//fim da classe.
