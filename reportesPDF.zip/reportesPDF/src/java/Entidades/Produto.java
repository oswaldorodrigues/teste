/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entidades;

/**
 * Classe para.....
 *
 * @author oswaldo rodrigues
 * @since Classe criada em 22/08/2016
 */

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@SuppressWarnings("serial")
@Entity
public class Produto extends GenericDomain {

    @Column(length = 150, nullable = false)
    private String nome;

    @Column(nullable = false)
    private String quantidade;



    @Column(nullable = false, precision = 7, scale = 2)
    private String precoDeCompra;

    @Column(length = 40, nullable = false)
    private String precoDeVenda;

    
    
    @Column(nullable = false)
    @Temporal(TemporalType.DATE)
    private Date dataCadastro;
    
    @Column(length = 20, nullable = false)
    private String status; 
    
    @ManyToOne
	@JoinColumn(nullable = false)
	private Categoria categoria;
    
    //@OneToOne
    //@JoinColumn(nullable = false)
    //private Fornecedor fornecedor;

    
    // getter and setter

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(String quantidade) {
        this.quantidade = quantidade;
    }

    public String getPrecoDeCompra() {
        return precoDeCompra;
    }

    public void setPrecoDeCompra(String precoDeCompra) {
        this.precoDeCompra = precoDeCompra;
    }

    public String getPrecoDeVenda() {
        return precoDeVenda;
    }

    public void setPrecoDeVenda(String precoDeVenda) {
        this.precoDeVenda = precoDeVenda;
    }

   

    public Date getDataCadastro() {
        return dataCadastro;
    }

    public void setDataCadastro(Date dataCadastro) {
        this.dataCadastro = dataCadastro;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }

   
    
   
}//fim da classe.
