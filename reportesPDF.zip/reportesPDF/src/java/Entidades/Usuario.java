package Entidades;

/**
 * Classe para.....
 *
 * @author Guilherme Montanher.
 * @since Classe criada em 22/08/2016
 */
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@SuppressWarnings("serial")
@Entity
public class Usuario extends GenericDomain {

    @Column(length = 50, nullable = false)
    private String login;

    @Column(length = 20, nullable = false)
    private String senha;

    @Column(length = 20, nullable = false)
    private String status;
    
     @OneToOne
    @JoinColumn(nullable = false)
    private Pessoa pessoa;
   

    
    // getter and setter
    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Pessoa getPessoa() {
        return pessoa;
    }

    public void setPessoa(Pessoa pessoa) {
        this.pessoa = pessoa;
    }

  
    
    

}//fim da classe.
