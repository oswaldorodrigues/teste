package Entidades;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;


/**
 * Classe para.....
 *
 * @author Guilherme Montanher.
 * @since Classe criada em 16/08/2016
 */

@SuppressWarnings("serial")
@Entity
public class Fornecedor extends GenericDomain{ 
    
    @Column(length = 50, nullable = false)
    private String razaoSocial;
    
    @Column(length = 80, nullable = false)
    private String nomeFantasia;
    
    @Column(length = 30, nullable = true)
    private String ie;
    
    @Column(length = 100, nullable = true)
    private String site;
    
    @Column(length = 10, nullable = false)
    private String status;
    
      @ManyToOne
	@JoinColumn(nullable = false)
	private Endereco endereco;
      
      @ManyToOne
	@JoinColumn(nullable = false)
	private Contato contato;
    
    // getter and setter
      

    public String getRazaoSocial() {
        return razaoSocial;
    }

    public void setRazaoSocial(String razaoSocial) {
        this.razaoSocial = razaoSocial;
    }

    public String getNomeFantasia() {
        return nomeFantasia;
    }

    public void setNomeFantasia(String nomeFantasia) {
        this.nomeFantasia = nomeFantasia;
    }

    public String getIe() {
        return ie;
    }

    public void setIe(String ie) {
        this.ie = ie;
    }

    public String getSite() {
        return site;
    }

    public void setSite(String site) {
        this.site = site;
    }

    public Endereco getEndereco() {
        return endereco;
    }

    public void setEndereco(Endereco endereco) {
        this.endereco = endereco;
    }

    public Contato getContato() {
        return contato;
    }

    public void setContato(Contato contato) {
        this.contato = contato;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

   
    
    
}//fim da classe.
