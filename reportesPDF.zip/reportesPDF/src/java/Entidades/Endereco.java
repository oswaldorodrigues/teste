/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Entidades;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

/**
 * Classe para.....
 * @author Guilherme Montanher.
 * @since Classe criada em 13/08/2016
 * 
 * Classe endereço para ser utilizada como atributo na class Pessoa
 */

@SuppressWarnings("serial")
@Entity
public class Endereco extends GenericDomain {
    
    	@Column(length = 150, nullable = false)
	private String logradouro;

	@Column(nullable = false)
	private Short numero;
        
        @Column(length = 30, nullable = false)
	private String cep;
        
         @Column(length = 30, nullable = false)
	private String cidade;
         
        @Column(length = 30, nullable = false)
	private String estado;
        
        
	@Column(length = 150, nullable = false)
	private String bairro;

	@Column(length = 50, nullable = true)
	private String complemento;
        
        // gettesr and setter

    public String getLogradouro() {
        return logradouro;
    }

    public void setLogradouro(String logradouro) {
        this.logradouro = logradouro;
    }

    public Short getNumero() {
        return numero;
    }

    public void setNumero(Short numero) {
        this.numero = numero;
    }

    public String getCep() {
        return cep;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }

    

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public String getComplemento() {
        return complemento;
    }

    public void setComplemento(String complemento) {
        this.complemento = complemento;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
        
        

}//fim da classe.
